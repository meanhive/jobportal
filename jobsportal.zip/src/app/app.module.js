"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var app_component_1 = require("./app.component");
var jobs_component_1 = require("./jobs/jobs.component");
var details_component_1 = require("./details/details.component");
var app_routing_1 = require("./app.routing");
var jobs_service_1 = require("./service/jobs.service");
var http_1 = require("@angular/http");
var forms_1 = require("@angular/forms");
var login_component_1 = require("./login/login.component");
var dashboard_component_1 = require("./dashboard/dashboard.component");
var auth_service_1 = require("./service/auth.service");
var femenu_component_1 = require("./femenu/femenu.component");
var adminmenu_component_1 = require("./adminmenu/adminmenu.component");
var new_component_1 = require("./new/new.component");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, app_routing_1.routingModule, http_1.HttpModule, forms_1.FormsModule, forms_1.ReactiveFormsModule],
        declarations: [app_component_1.AppComponent,
            jobs_component_1.JobsComponent,
            details_component_1.DetailsComponent,
            login_component_1.LoginComponent,
            dashboard_component_1.DashboardComponent,
            femenu_component_1.Femenu,
            adminmenu_component_1.AdminMenu,
            new_component_1.NewComponent],
        providers: [app_routing_1.appRoutingProvider, jobs_service_1.JobsService, auth_service_1.AuthService],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map