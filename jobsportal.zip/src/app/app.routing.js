"use strict";
var router_1 = require("@angular/router");
var jobs_component_1 = require("./jobs/jobs.component");
var details_component_1 = require("./details/details.component");
var login_component_1 = require("./login/login.component");
var dashboard_component_1 = require("./dashboard/dashboard.component");
var new_component_1 = require("./new/new.component");
var routes = [
    {
        path: '',
        redirectTo: 'jobs',
        pathMatch: 'full'
    },
    {
        path: 'jobs',
        component: jobs_component_1.JobsComponent
    },
    {
        path: 'details/:id',
        component: details_component_1.DetailsComponent
    },
    {
        path: 'admin',
        component: login_component_1.LoginComponent
    },
    {
        path: 'dashboard',
        component: dashboard_component_1.DashboardComponent
    },
    {
        path: 'new',
        component: new_component_1.NewComponent
    }
];
exports.appRoutingProvider = [];
exports.routingModule = router_1.RouterModule.forRoot(routes);
//# sourceMappingURL=app.routing.js.map