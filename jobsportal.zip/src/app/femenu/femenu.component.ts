import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: 'app-femenu',
    templateUrl: 'femenu.component.html'
})

export class Femenu {

}
