import { Component, OnInit } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: 'app-new',
    templateUrl: 'new.component.html'
})

export class NewComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
