import { Injectable } from "@angular/core";
import { Http } from "@angular/http";

@Injectable()

export class JobsService {
    baseUrl: any = "http://localhost:3000";

    constructor(private http: Http) {}

    // read all jobs list

    getJobs() {
        return this.http.get(this.baseUrl + '/jobs');
    }

    // read single job profile

    getSingleJob(id:any) {
        return this.http.get(this.baseUrl + '/jobs/' + id);
    }

}
